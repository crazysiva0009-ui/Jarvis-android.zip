package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.SmsManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {

    // ---- palette (dark, amber accent) ----
    private val bg = Color.parseColor("#0F1318")
    private val surface = Color.parseColor("#171D25")
    private val line = Color.parseColor("#263040")
    private val fg = Color.parseColor("#E8ECF1")
    private val muted = Color.parseColor("#8B97A7")
    private val accent = Color.parseColor("#FFB020")
    private val accentFg = Color.parseColor("#1B1300")

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var router: Router
    private lateinit var logBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var statusView: TextView
    private lateinit var micBtn: Button
    private lateinit var handsFreeBtn: Button

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var handsFree = false
    private var awaitCommand = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var pendingPermission: (() -> Unit)? = null
    private val wake = listOf("jarvis", "ஜார்விஸ்", "ஜார்விஸ", "ஜார்வீஸ்", "ஜார்வி", "jarvish", "jarwis")

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        router = Router(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        tts = TextToSpeech(this) { status -> ttsReady = status == TextToSpeech.SUCCESS }

        addMsg(
            "Jarvis",
            if (Store.key.isBlank()) "Vanakkam, naan Jarvis. Mudhalil Settings-la Gemini API key podunga (free), appuram pesalam."
            else "Vanakkam, naan Jarvis. Mic tap pannunga illa type pannunga."
        )
        // Ask for everything once, up front, so later commands just work.
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS
            ), 100
        )
    }

    override fun onDestroy() {
        stopRecognizer()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, permissions, results)
        if (code == 101) {
            val run = pendingPermission
            pendingPermission = null
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) run?.invoke()
            else addMsg("Jarvis", "Permission kidaikkala. Phone Settings > Apps > Jarvis > Permissions-la allow pannunga.")
        }
    }

    /** Runs [then] once [perm] is granted (asks if needed). */
    private fun withPermission(perm: String, then: () -> Unit) {
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) then()
        else {
            pendingPermission = then
            requestPermissions(arrayOf(perm), 101)
        }
    }

    // ------------------------------------------------------------------ UI
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun flatButton(label: String, filled: Boolean): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; minHeight = 0; minimumHeight = 0
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setTextColor(if (filled) accentFg else fg)
        background = if (filled) rounded(accent, 10) else rounded(Color.TRANSPARENT, 10, line)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "JARVIS"; setTextColor(fg); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.18f
        })
        statusView = TextView(this).apply {
            text = "Ready"; setTextColor(muted); textSize = 13f; setPadding(dp(10), 0, 0, 0)
        }
        header.addView(statusView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        handsFreeBtn = flatButton("Hands-free", false).apply { setOnClickListener { toggleHandsFree() } }
        header.addView(handsFreeBtn)
        header.addView(flatButton("Settings", false).apply {
            setOnClickListener { showSettings() }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        root.addView(header)

        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(logBox); isFillViewport = false }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val chips = LinearLayout(this)
        listOf(
            "Battery" to "battery evlo?",
            "Inniku plan" to "iniku plan ena?",
            "Drama concept" to "micro drama concept: college la oru ghost love story",
            "Part 1 script" to "part 1 script eludhu",
            "Reel ideas" to "fitness reels ku idea sollu",
            "WhatsApp" to "whatsapp la yaru text pannirukka?"
        ).forEach { (label, q) ->
            chips.addView(flatButton(label, false).apply { setOnClickListener { submit(q) } },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6); bottomMargin = dp(8) })

        val composer = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Type or tap the mic"; setHintTextColor(muted); setTextColor(fg); textSize = 16f
            background = rounded(surface, 12, line); setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = InputType.TYPE_CLASS_TEXT; imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
            }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        composer.addView(flatButton("Send", false).apply { setOnClickListener { sendTyped() } },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        micBtn = Button(this).apply {
            text = "Mic"; isAllCaps = false; setTextColor(accentFg); typeface = Typeface.DEFAULT_BOLD
            background = rounded(accent, 30); setOnClickListener { onMicTap() }
        }
        composer.addView(micBtn, LinearLayout.LayoutParams(dp(64), dp(60)).apply { leftMargin = dp(8) })
        root.addView(composer)

        setContentView(root)
    }

    private fun addMsg(who: String, text: String, extra: List<View> = emptyList()) {
        val isYou = who == "You"
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (isYou) { background = rounded(surface, 14, line); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        }
        if (!isYou) box.addView(TextView(this).apply {
            this.text = who.uppercase(); setTextColor(accent); textSize = 11f; letterSpacing = 0.12f
        })
        box.addView(TextView(this).apply { this.text = text; setTextColor(fg); textSize = 16f; setTextIsSelectable(true) })
        extra.forEach { box.addView(it) }
        val lp = LinearLayout.LayoutParams(
            if (isYou) LinearLayout.LayoutParams.WRAP_CONTENT else LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14); if (isYou) gravity = Gravity.END }
        logBox.addView(box, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sceneViews(s: Script): List<View> = s.scenes.mapIndexed { i, sc ->
        TextView(this).apply {
            text = "Scene ${i + 1}: ${sc.caption}\nVisual: ${sc.visual}\nVoice: ${sc.voice}"
            setTextColor(fg); textSize = 14f; setTextIsSelectable(true); setPadding(0, dp(10), 0, 0)
        }
    }

    private fun setStatus(s: String) { statusView.text = s }

    // ------------------------------------------------------------------ input handling
    private fun sendTyped() {
        val t = input.text.toString().trim()
        input.setText("")
        if (t.isNotEmpty()) submit(t)
    }

    private fun submit(text: String) {
        addMsg("You", text)
        setStatus("Thinking...")
        Thread {
            val reply = try {
                router.handle(text)
            } catch (e: SecurityException) {
                Reply("Permission venum (contacts/phone/SMS). Settings > Grant permissions.")
            } catch (e: Exception) {
                Reply("Edho thappu nadandhadhu: ${e.message}")
            }
            runOnUiThread { showReply(reply) }
        }.start()
    }

    private fun showReply(r: Reply) {
        setStatus(if (listening) "Listening" else "Ready")
        addMsg("Jarvis", r.text, r.script?.let { sceneViews(it) } ?: emptyList())
        r.act?.let { perform(it) }
        speak(r.text) { if (handsFree) startListening() }
    }

    // ------------------------------------------------------------------ phone actions
    private fun perform(act: Act) {
        when (act) {
            is Act.Call -> confirm("${act.name} (${act.number}) ku call pannava?") {
                withPermission(Manifest.permission.CALL_PHONE) {
                    try {
                        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + act.number)))
                    } catch (e: Exception) { addMsg("Jarvis", "Call start aagala: ${e.message}") }
                }
            }
            is Act.Sms -> confirm("${act.name} ku SMS anuppava?\n\n\"${act.body}\"") {
                withPermission(Manifest.permission.SEND_SMS) { sendSms(act) }
            }
            is Act.WhatsApp -> try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(act.url)))
            } catch (e: ActivityNotFoundException) { addMsg("Jarvis", "WhatsApp open aagala.") }
            is Act.Alarm -> try {
                startActivity(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, act.hour)
                        .putExtra(AlarmClock.EXTRA_MINUTES, act.minute)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
            } catch (e: Exception) { addMsg("Jarvis", "Alarm app kidaikkala.") }
            is Act.Torch -> try {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], act.on)
            } catch (e: Exception) { addMsg("Jarvis", "Torch control aagala.") }
        }
    }

    private fun sendSms(act: Act.Sms) {
        try {
            @Suppress("DEPRECATION")
            val sm: SmsManager = if (android.os.Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(act.number, null, sm.divideMessage(act.body), null, null)
            addMsg("Jarvis", "${act.name} ku SMS anuppitten.")
        } catch (e: Exception) {
            addMsg("Jarvis", "SMS anuppa mudiyala: ${e.message}")
        }
    }

    private fun confirm(question: String, yes: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(question)
            .setPositiveButton("Confirm") { _, _ -> yes() }
            .setNegativeButton("Cancel") { _, _ -> addMsg("Jarvis", "Seri, cancel pannitten.") }
            .show()
    }

    // ------------------------------------------------------------------ speech out
    private fun speak(text: String, done: () -> Unit) {
        val engine = tts
        if (!Store.speakReplies || engine == null || !ttsReady) { done(); return }
        stopRecognizer()
        val tamil = text.any { it in '஀'..'௿' }
        engine.language = if (tamil) Locale("ta", "IN") else Locale("en", "IN")
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { runOnUiThread { done() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { runOnUiThread { done() } }
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // ------------------------------------------------------------------ speech in
    private fun onMicTap() {
        if (listening) stopRecognizer() else startListening()
    }

    private fun toggleHandsFree() {
        handsFree = !handsFree
        handsFreeBtn.background = if (handsFree) rounded(Color.TRANSPARENT, 10, accent) else rounded(Color.TRANSPARENT, 10, line)
        if (handsFree) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            addMsg("Jarvis", "Hands-free ON. 'Jarvis ...' nu sollunga. App open-la, screen on-la irukkanum.")
            startListening()
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            stopRecognizer()
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMsg("Jarvis", "Indha phone-la speech recognition illa. Google app update pannunga, illana type pannunga.")
            return
        }
        withPermission(Manifest.permission.RECORD_AUDIO) { beginRecognition() }
    }

    private fun beginRecognition() {
        stopRecognizer()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; setStatus(if (handsFree) "Say \"Jarvis ...\"" else "Listening"); micBtn.text = "Stop" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank() && !handsFree) input.setText(p)
            }

            override fun onResults(results: Bundle?) {
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim() ?: ""
                finishListening()
                input.setText("")
                if (heard.isEmpty()) { if (handsFree) restartSoon(300); return }
                if (!handsFree) { submit(heard); return }
                if (awaitCommand) { awaitCommand = false; submit(heard); return }
                if (wake.any { heard.lowercase().contains(it) }) {
                    val cmd = stripWake(heard)
                    if (cmd.isBlank()) {
                        awaitCommand = true
                        addMsg("Jarvis", "Sollunga.")
                        speak("Sollunga.") { startListening() }
                    } else submit(cmd)
                } else restartSoon(200)
            }

            override fun onError(error: Int) {
                finishListening()
                awaitCommand = false
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    handsFree = false
                    addMsg("Jarvis", "Mic permission venum. Phone Settings > Apps > Jarvis > Permissions.")
                    return
                }
                if (handsFree) restartSoon(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 400)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Store.lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.startListening(i)
    }

    private fun stripWake(t: String): String {
        var out = t
        for (w in wake.sortedByDescending { it.length }) out = out.replace(Regex("(?i)(?:\\b(?:hi|hey|hello)\\s+)?" + Regex.escape(w) + "[,.!]?"), "")
        return out.trim()
    }

    private fun restartSoon(ms: Long) { ui.postDelayed({ if (handsFree && !listening) startListening() }, ms) }

    private fun finishListening() {
        listening = false
        micBtn.text = "Mic"
        setStatus("Ready")
        recognizer?.destroy()
        recognizer = null
    }

    private fun stopRecognizer() {
        listening = false
        if (::micBtn.isInitialized) micBtn.text = "Mic"
        recognizer?.destroy()
        recognizer = null
    }

    // ------------------------------------------------------------------ settings
    private fun showSettings() {
        val pad = dp(20)
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun field(label: String, value: String, secret: Boolean = false): EditText {
            form.addView(TextView(this).apply { text = label; textSize = 13f })
            return EditText(this).apply {
                setText(value); setSingleLine()
                inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
            }.also { form.addView(it) }
        }
        val keyF = field("Gemini API key (free: aistudio.google.com/apikey)", Store.key, true)
        val modelF = field("Gemini model", Store.model)
        form.addView(TextView(this).apply { text = "Voice language"; textSize = 13f; setPadding(0, dp(12), 0, 0) })
        val langs = listOf("ta-IN" to "Tamil (ta-IN)", "en-IN" to "English India (en-IN)")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, langs.map { it.second })
            setSelection(langs.indexOfFirst { it.first == Store.lang }.coerceAtLeast(0))
        }
        form.addView(spinner)
        val speakBox = CheckBox(this).apply { text = "Speak replies aloud"; isChecked = Store.speakReplies }
        form.addView(speakBox)
        form.addView(Button(this).apply {
            text = "Enable WhatsApp access (notification access)"; isAllCaps = false
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        })
        form.addView(Button(this).apply {
            text = "Grant permissions again"; isAllCaps = false
            setOnClickListener {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS), 100)
            }
        })
        form.addView(TextView(this).apply {
            text = "Key and data stay on this phone only. Calls and SMS always ask you to confirm."
            textSize = 12f; setPadding(0, dp(8), 0, 0)
        })
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("Save") { _, _ ->
                Store.key = keyF.text.toString().trim()
                Store.model = modelF.text.toString().trim()
                Store.lang = langs[spinner.selectedItemPosition].first
                Store.speakReplies = speakBox.isChecked
                addMsg("Jarvis", "Settings save aachu.")
            }
            .setNegativeButton("Close", null)
            .show()
    }
}
