package com.jarvis.app

/** Safe arithmetic (no eval). Returns a spoken answer or null if the text is not plain maths. */
object Calc {
    fun answer(input: String): String? {
        var e = input.lowercase()
        val subs = listOf(
            "multiply by" to "*", "divided by" to "/", "% of" to "/100*", "percent of" to "/100*",
            "plus" to "+", "minus" to "-", "times" to "*", "x" to "*", "×" to "*", "÷" to "/", "," to ""
        )
        for ((a, b) in subs) e = e.replace(a, b)
        e = e.replace(Regex("[^0-9+\\-*/().% ]"), "").trim()
        if (!e.any { it.isDigit() } || !e.any { it in "+-*/%" }) return null
        e = e.replace(Regex("(\\d+(?:\\.\\d+)?)%"), "($1/100)")
        return try {
            val p = Parser(e)
            val v = p.parse()
            val r = Math.round(v * 10000.0) / 10000.0
            "Answer " + (if (r == Math.floor(r) && Math.abs(r) < 1e15) r.toLong().toString() else r.toString()) + "."
        } catch (ex: Exception) {
            null
        }
    }

    private class Parser(val s: String) {
        var i = 0
        fun peek(): Char? {
            while (i < s.length && s[i] == ' ') i++
            return if (i < s.length) s[i] else null
        }

        fun parse(): Double {
            val v = add()
            if (peek() != null) throw IllegalArgumentException("trailing")
            return v
        }

        fun add(): Double {
            var v = mul()
            while (true) {
                when (peek()) {
                    '+' -> { i++; v += mul() }
                    '-' -> { i++; v -= mul() }
                    else -> return v
                }
            }
        }

        fun mul(): Double {
            var v = num()
            while (true) {
                when (peek()) {
                    '*' -> { i++; v *= num() }
                    '/' -> { i++; val d = num(); if (d == 0.0) throw ArithmeticException(); v /= d }
                    else -> return v
                }
            }
        }

        fun num(): Double {
            when (peek()) {
                '(' -> { i++; val v = add(); if (peek() != ')') throw IllegalArgumentException(); i++; return v }
                '-' -> { i++; return -num() }
                '+' -> { i++; return num() }
            }
            val m = Regex("^\\d+(\\.\\d+)?").find(s.substring(i)) ?: throw IllegalArgumentException()
            i += m.value.length
            return m.value.toDouble()
        }
    }
}
