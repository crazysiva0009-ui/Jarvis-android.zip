package com.jarvis.app

import android.content.Context
import android.provider.ContactsContract

data class Contact(val name: String, val number: String)

object Contacts {
    /** Finds a contact by (partial) name, or accepts a raw phone number. Needs READ_CONTACTS. */
    fun find(ctx: Context, query: String): Contact? {
        val q = query.trim()
        if (q.isEmpty()) return null
        val digits = q.replace(" ", "")
        if (Regex("^\\+?\\d{6,}$").matches(digits)) return Contact(digits, digits)

        var partial: Contact? = null
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        ) ?: return null
        cursor.use {
            while (it.moveToNext()) {
                val name = it.getString(0) ?: continue
                val number = (it.getString(1) ?: continue).replace(Regex("[^\\d+]"), "")
                if (name.equals(q, ignoreCase = true)) return Contact(name, number)
                if (partial == null && name.contains(q, ignoreCase = true)) partial = Contact(name, number)
            }
        }
        return partial
    }
}
