package com.jarvis.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Tiny settings + data store (SharedPreferences). Everything stays on the phone. */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    }

    var key: String
        get() = sp.getString("key", "") ?: ""
        set(v) = sp.edit().putString("key", v).apply()

    var model: String
        get() = sp.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
        set(v) = sp.edit().putString("model", v.ifBlank { "gemini-3.8-flash" }).apply()

    /** "ta-IN" or "en-IN" */
    var lang: String
        get() = sp.getString("lang", "ta-IN") ?: "ta-IN"
        set(v) = sp.edit().putString("lang", v).apply()

    var speakReplies: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) = sp.edit().putBoolean("speak", v).apply()

    // ---- tasks ----
    fun tasks(): MutableList<String> {
        val arr = JSONArray(sp.getString("tasks", "[]") ?: "[]")
        return MutableList(arr.length()) { arr.getString(it) }
    }

    fun saveTasks(list: List<String>) {
        sp.edit().putString("tasks", JSONArray(list).toString()).apply()
    }

    // ---- micro drama ----
    var concept: String
        get() = sp.getString("concept", "") ?: ""
        set(v) = sp.edit().putString("concept", v).apply()

    /** part number -> raw JSON {"title":..., "scenes":[...]} */
    fun parts(): JSONObject = JSONObject(sp.getString("parts", "{}") ?: "{}")

    fun savePart(part: Int, data: JSONObject) {
        val p = parts()
        p.put(part.toString(), data)
        sp.edit().putString("parts", p.toString()).apply()
    }

    fun resetDrama(newConcept: String) {
        sp.edit().putString("concept", newConcept).putString("parts", "{}").apply()
    }
}
