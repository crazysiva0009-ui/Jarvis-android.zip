package com.jarvis.app

import android.service.notification.NotificationListenerService

/**
 * Lets Jarvis see which WhatsApp chats have unread notifications.
 * The user must switch it on in Settings > Notification access.
 */
class JarvisNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }

    companion object {
        @Volatile var instance: JarvisNotificationListener? = null
        private val WHATSAPP = setOf("com.whatsapp", "com.whatsapp.w4b")

        /** Spoken summary, or null if the listener is not enabled. */
        fun whatsappSummary(): String? {
            val svc = instance ?: return null
            val counts = LinkedHashMap<String, Int>()
            for (n in svc.activeNotifications ?: emptyArray()) {
                if (n.packageName !in WHATSAPP) continue
                val title = n.notification.extras.getCharSequence("android.title")?.toString() ?: continue
                if (title.startsWith("WhatsApp", ignoreCase = true)) continue
                counts[title] = (counts[title] ?: 0) + 1
            }
            if (counts.isEmpty()) return "Pudhusa WhatsApp message illa."
            return "WhatsApp-la " + counts.entries.take(6).joinToString(", ") { "${it.key} (${it.value})" } +
                " message pannirukkaanga."
        }
    }
}
