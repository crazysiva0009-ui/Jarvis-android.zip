package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Gemini free-tier client. Blocking: call from a background thread. */
object Gemini {
    const val SYSTEM = "You are Jarvis, a friendly personal assistant. The user speaks Tamil, English or " +
        "Tanglish (Tamil written in English letters). Reply in the same style the user used, short and " +
        "clear (2-4 sentences) because replies are spoken aloud. For content ideas be creative and practical."
    const val DECISION = "Help the user decide. Give a clear recommendation first, then 2 pros and 2 cons, " +
        "include any simple calculation. Be brief (spoken aloud)."

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"
    private val history = mutableListOf<Pair<String, String>>() // role, text

    private class Resp(val code: Int, val json: JSONObject?)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun request(url: String, body: JSONObject?): Resp {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 45000
        if (body != null) {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        val json = try { JSONObject(raw) } catch (e: Exception) { null }
        return Resp(code, json)
    }

    private fun errorText(r: Resp): String = r.json?.optJSONObject("error")?.optString("message") ?: "unknown"

    /**
     * Asks Google which models this key can use and picks the newest plain "flash" model
     * (not lite/image/tts/live). Saves it so the app keeps working when Google retires a model.
     */
    private fun discoverModel(): String? {
        val r = request(BASE + "models?pageSize=200&key=" + enc(Store.key), null)
        val list = r.json?.optJSONArray("models") ?: return null
        var best: String? = null
        var bestVer = -1.0
        val skip = listOf("lite", "image", "tts", "live", "audio", "embed", "robotics", "computer", "8b", "exp", "thinking")
        for (i in 0 until list.length()) {
            val m = list.getJSONObject(i)
            val name = m.optString("name").removePrefix("models/")
            val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
            val canGenerate = (0 until methods.length()).any { methods.getString(it) == "generateContent" }
            if (!canGenerate || !name.startsWith("gemini-") || !name.contains("flash")) continue
            if (skip.any { name.contains(it) }) continue
            val ver = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(name)?.groupValues?.get(1)?.toDoubleOrNull() ?: continue
            // prefer stable (no "preview") when versions tie
            val score = ver + if (name.contains("preview")) 0.0 else 0.001
            if (score > bestVer) { bestVer = score; best = name }
        }
        return best
    }

    private fun generate(model: String, body: JSONObject): Resp =
        request(BASE + "models/" + enc(model) + ":generateContent?key=" + enc(Store.key), body)

    fun ask(prompt: String, system: String = SYSTEM, remember: Boolean = true, retried: Boolean = false): String {
        if (Store.key.isBlank()) {
            return "Settings-la Gemini API key podunga (aistudio.google.com/apikey, free)."
        }
        val turns = if (remember) history.takeLast(16).toMutableList() else mutableListOf()
        turns.add("user" to prompt)
        val contents = JSONArray()
        for ((role, text) in turns) {
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)

        return try {
            var resp = generate(Store.model, body)
            // Retired / unknown model: find a working one automatically and retry once.
            if (resp.code == 404 || resp.code == 400 && errorText(resp).contains("model", ignoreCase = true)) {
                val found = discoverModel()
                if (found != null && found != Store.model) {
                    Store.model = found
                    resp = generate(found, body)
                }
            }
            if (resp.code !in 200..299) {
                return "Gemini error (${resp.code}): ${errorText(resp)} [model: ${Store.model}]"
            }
            val out = resp.json!!.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
            if (remember) {
                history.add("user" to prompt)
                history.add("model" to out)
            }
            out
        } catch (e: Exception) {
            "Internet illa, illana Gemini respond pannala."
        }
    }

    /** Asks Google which models this key can use and returns the newest stable Flash one (or null). */
    private fun newestFlashModel(): String? {
        return try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=" +
                URLEncoder.encode(Store.key, "UTF-8")
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            if (conn.responseCode !in 200..299) return null
            val models = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                .getJSONArray("models")
            val rx = Regex("^gemini-(\\d+(?:\\.\\d+)?)-flash(-preview.*)?$")
            val skip = listOf("lite", "image", "tts", "live", "audio", "exp", "thinking", "embedding")
            var best: String? = null
            var bestKey = Pair(-1.0, 0)
            for (i in 0 until models.length()) {
                val m = models.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                if ((0 until methods.length()).none { methods.getString(it) == "generateContent" }) continue
                val id = m.optString("name").removePrefix("models/")
                if (skip.any { id.contains(it) }) continue
                val match = rx.find(id) ?: continue
                val key = Pair(match.groupValues[1].toDouble(), if (match.groupValues[2].isEmpty()) 1 else 0)
                if (key.first > bestKey.first || (key.first == bestKey.first && key.second > bestKey.second)) {
                    best = id; bestKey = key
                }
            }
            best
        } catch (e: Exception) {
            null
        }
    }
}
