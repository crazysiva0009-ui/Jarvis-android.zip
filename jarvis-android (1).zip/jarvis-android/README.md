# Jarvis (native Android app)

Kotlin, no third-party libraries. Tamil / English / Tanglish voice assistant:
- Voice in (Android SpeechRecognizer, Tamil + English) and voice out (TextToSpeech)
- Gemini chat, micro-drama scripts per part, reel ideas, captions, decisions
- Calls and SMS (with a Confirm dialog), WhatsApp chat opener, alarm, torch, battery, tasks, calculator
- "Who texted on WhatsApp?" via Notification access (sender names only, no message history)
- Hands-free "Jarvis ..." while the app is open and the screen is on

## Get the APK (no Android Studio needed)
1. Create a GitHub repo and upload this whole folder (keep `.github/workflows/build.yml`).
2. Open the repo > Actions > "Build APK" > Run workflow (it also runs on every push).
3. When it turns green, open the run > Artifacts > download `jarvis-debug-apk`, unzip.
4. Copy `app-debug.apk` to the phone, tap it, allow "Install unknown apps" for your file manager/Chrome.

(With Android Studio: File > Open this folder > Run.)

## First run
Allow Mic, Contacts, Phone and SMS when asked. Settings: paste a free Gemini key
(aistudio.google.com/apikey). For WhatsApp sender names: Settings > Enable WhatsApp access > turn on "Jarvis".
On Realme: Battery > Jarvis > allow background activity.

## Limits
- Hands-free is not an always-on background service (Android restricts that); keep the app open.
- No video file generation here (use the Termux version, or copy scripts into CapCut).
- Debug-signed APK for personal use. Gemini key is stored in app storage on the phone.
- The code type-checks against the Android 34 SDK, but this build was never run on a phone by its author.
