package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Gemini free-tier client. Blocking: call from a background thread. */
object Gemini {
    const val SYSTEM = "You are Jarvis, a friendly personal assistant. The user speaks Tamil, English or " +
        "Tanglish (Tamil written in English letters). Reply in the same style the user used, short and " +
        "clear (2-4 sentences) because replies are spoken aloud. For content ideas be creative and practical."
    const val DECISION = "Help the user decide. Give a clear recommendation first, then 2 pros and 2 cons, " +
        "include any simple calculation. Be brief (spoken aloud)."

    private val history = mutableListOf<Pair<String, String>>() // role, text

    fun ask(prompt: String, system: String = SYSTEM, remember: Boolean = true): String {
        if (Store.key.isBlank()) {
            return "Settings-la Gemini API key podunga (aistudio.google.com/apikey, free)."
        }
        val turns = if (remember) history.takeLast(16).toMutableList() else mutableListOf()
        turns.add("user" to prompt)

        val contents = JSONArray()
        for ((role, text) in turns) {
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)

        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            URLEncoder.encode(Store.model, "UTF-8") + ":generateContent?key=" + URLEncoder.encode(Store.key, "UTF-8")
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val json = JSONObject(raw)
            if (code !in 200..299) {
                val msg = json.optJSONObject("error")?.optString("message") ?: "unknown"
                return "Gemini error ($code): $msg [model: ${Store.model}]"
            }
            val out = json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
            if (remember) {
                history.add("user" to prompt)
                history.add("model" to out)
            }
            out
        } catch (e: Exception) {
            "Internet illa, illana Gemini respond pannala."
        }
    }
}
