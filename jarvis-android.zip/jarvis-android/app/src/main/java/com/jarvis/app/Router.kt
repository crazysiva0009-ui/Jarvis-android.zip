package com.jarvis.app

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Something the phone should do after Jarvis answers. */
sealed class Act {
    /** Needs a spoken/tapped confirmation first. */
    data class Call(val name: String, val number: String) : Act()
    data class Sms(val name: String, val number: String, val body: String) : Act()
    /** Opens WhatsApp chat/prefilled message (user taps send). */
    data class WhatsApp(val url: String) : Act()
    data class Alarm(val hour: Int, val minute: Int) : Act()
    data class Torch(val on: Boolean) : Act()
}

data class Scene(val caption: String, val voice: String, val visual: String)
data class Script(val part: Int, val title: String, val scenes: List<Scene>)
data class Reply(val text: String, val act: Act? = null, val script: Script? = null)

/** Turns Tamil / English / Tanglish text into a Reply. Blocking (may call Gemini): use a background thread. */
class Router(private val ctx: Context) {

    // keyword groups: English / Tanglish / Tamil script (Google STT may return Tamil script)
    private val battery = listOf("battery", "charge evlo", "பேட்டரி", "சார்ஜ்")
    private val timeW = listOf("neram", "time", "நேரம்", "மணி என்ன", "டைம்")
    private val torch = listOf("torch", "flashlight", "tochu", "டார்ச்", "டார்ச்சு", "லைட்")
    private val off = listOf("off", "aff", "nirutthu", "ஆஃப்", "நிறுத்து")
    private val whatsapp = listOf("whatsapp", "வாட்ஸ்அப்", "வாட்ஸ்ஆப்", "வாட்சப்", "வாட்ஸப்")
    private val who = listOf("yaru", "who", "text", "message", "msg", "யாரு", "யார்", "மெசேஜ்", "டெக்ஸ்ட்")
    private val sendW = listOf("anuppu", "anupu", "send", "அனுப்பு")
    private val sms = listOf("sms", "text anuppu", "message anuppu", "msg anuppu", "send message", "எஸ்எம்எஸ்", "மெசேஜ் அனுப்பு")
    private val call = listOf("call", "கால்", "போன் பண்ணு", "போன் செய்")
    private val alarm = listOf("alarm", "அலாரம்")
    private val tasksW = listOf("tasks", "iniku plan", "inniku plan", "today plan", "plan ena", "இன்னிக்கு பிளான்", "இன்னைக்கு பிளான்", "பிளான் என்ன")
    private val clearTasks = listOf("clear tasks", "tasks clear", "டாஸ்க் கிளியர்")
    private val video = listOf("video", "வீடியோ")
    private val makeW = listOf("generate", "pannu", "panu", "make", "create", "பண்ணு", "உருவாக்கு")
    private val drama = listOf("micro drama", "script", "next part", "மைக்ரோ டிராமா", "ஸ்கிரிப்ட்", "ஸ்கிரிப்டு")
    private val partW = listOf("part", "script", "eludhu", "write", "பார்ட்", "எழுது", "ஸ்கிரிப்ட்")
    private val caption = listOf("hashtag", "caption", "ஹேஷ்டேக்", "கேப்ஷன்")
    private val idea = listOf("idea", "trending", "trend", "youtube", "ஐடியா", "ட்ரெண்டிங்", "யூடியூப்")
    private val decide = listOf("decide", "which is better", "edhu nalladhu", "suggest", "should i", "venuma", "வேணுமா", "வாங்கலாமா", "எது நல்லது", "முடிவு")

    private val filler = setOf(
        "pannu", "panu", "pannunga", "panunga", "please", "plz", "ku", "ki", "kku", "ah", "a", "call", "to",
        "ennaku", "enakku", "ena", "na", "nu", "பண்ணு", "பண்ணுங்க", "பன்னு", "கால்", "ப்ளீஸ்", "எனக்கு", "ஒரு", "போன்", "செய்"
    )
    private val tamilNames = mapOf(
        "அம்மா" to "amma", "அம்மாவுக்கு" to "amma", "அம்மாக்கு" to "amma",
        "அப்பா" to "appa", "அப்பாவுக்கு" to "appa", "அப்பாக்கு" to "appa",
        "அண்ணா" to "anna", "அண்ணனுக்கு" to "anna", "அக்கா" to "akka", "அக்காவுக்கு" to "akka",
        "தம்பி" to "thambi", "தம்பிக்கு" to "thambi", "தங்கை" to "thangai", "தங்கைக்கு" to "thangai",
        "வீடு" to "home", "வீட்டுக்கு" to "home", "வீட்டிற்கு" to "home"
    )

    private fun has(t: String, words: List<String>) = words.any { t.contains(it) }
    private fun tokens(t: String) = t.split(Regex("[\\s,.!?:;]+")).filter { it.isNotEmpty() }
    private fun nameFrom(t: String, drop: Set<String> = emptySet()): String =
        tokens(t).filter { it !in filler && it !in drop }.joinToString(" ") { tamilNames[it] ?: it }.trim()

    fun handle(text: String): Reply {
        val t = text.lowercase().trim()
        if (t.isEmpty()) return Reply("Sollunga, ketkuren.")

        // ---- system ----
        if (has(t, battery)) return Reply(batteryText())
        if (has(t, timeW) && !has(t, alarm) && t.split(Regex("\\s+")).size <= 4) {
            val f = SimpleDateFormat("hh:mm a, EEEE, d MMMM", Locale.ENGLISH)
            return Reply("Ippo neram " + f.format(Date()) + ".")
        }
        if (has(t, torch)) {
            val on = !has(t, off)
            return Reply(if (on) "Torch on." else "Torch off.", Act.Torch(on))
        }

        // ---- WhatsApp / SMS / calls ----
        if (has(t, whatsapp) && has(t, who) && !t.contains(":") && !has(t, sendW)) {
            return Reply(
                JarvisNotificationListener.whatsappSummary()
                    ?: "WhatsApp padikka Settings > Enable WhatsApp access ON pannunga."
            )
        }
        if (has(t, whatsapp) && has(t, sendW)) {
            val head = text.substringBefore(":")
            val msg = if (text.contains(":")) text.substringAfter(":").trim() else ""
            val name = nameFrom(head.lowercase(), setOf("whatsapp", "வாட்ஸ்அப்", "message", "மெசேஜ்", "anuppu", "அனுப்பு", "send", "jarvis"))
            val c = Contacts.find(ctx, name) ?: return Reply("${name.ifBlank { "Andha" }} contact illa.")
            val url = "https://wa.me/" + c.number.removePrefix("+") +
                (if (msg.isNotEmpty()) "?text=" + java.net.URLEncoder.encode(msg, "UTF-8") else "")
            return Reply("WhatsApp-la ${c.name} chat open panren.", Act.WhatsApp(url))
        }
        if (has(t, sms)) {
            val head = text.substringBefore(":")
            val msg = if (text.contains(":")) text.substringAfter(":").trim() else ""
            val name = nameFrom(head.lowercase(), setOf("sms", "text", "message", "msg", "anuppu", "send", "anupu", "எஸ்எம்எஸ்", "மெசேஜ்", "அனுப்பு", "jarvis"))
            val c = Contacts.find(ctx, name) ?: return Reply("${name.ifBlank { "Andha" }} contact illa.")
            if (msg.isEmpty()) return Reply("Message-um sollunga. Example: '${c.name} ku sms anuppu: seekiram vaa'.")
            return Reply("${c.name} ku SMS ready.", Act.Sms(c.name, c.number, msg))
        }
        if (has(t, call)) {
            val name = nameFrom(t, setOf("jarvis", "ஜார்விஸ்"))
            if (name.isEmpty()) return Reply("Yaaru ku call pannanum?")
            val c = Contacts.find(ctx, name) ?: return Reply("$name contact illa.")
            return Reply("${c.name} ku call panren.", Act.Call(c.name, c.number))
        }

        // ---- alarm / tasks ----
        if (has(t, alarm)) {
            val p = parseTime(t) ?: return Reply("Enna neram alarm vekkanum?")
            return Reply("Alarm %02d:%02d ku set panren.".format(p.first, p.second), Act.Alarm(p.first, p.second))
        }
        if (Regex("\\btask (add|podu)|\\badd task|டாஸ்க் (சேர்|போடு)").containsMatchIn(t)) {
            val item = t.replace(Regex("(task|add|podu|pannu|டாஸ்க்|சேர்|போடு|பண்ணு)"), "").trim(' ', ':')
            if (item.isEmpty()) return Reply("Enna task add pannanum?")
            val list = Store.tasks(); list.add(item); Store.saveTasks(list)
            return Reply("Task add pannitten: $item")
        }
        if (has(t, clearTasks)) { Store.saveTasks(emptyList()); return Reply("Ellaa tasks-um clear pannitten.") }
        if (has(t, tasksW)) {
            val list = Store.tasks()
            if (list.isNotEmpty()) return Reply("Ungal tasks: " + list.withIndex().joinToString("; ") { "${it.index + 1}. ${it.value}" })
            return Reply(Gemini.ask("Give me a simple productive plan for today, 3 short points.", remember = false))
        }

        // ---- content creation ----
        if ((t.contains("concept") || t.contains("கான்செப்ட்")) && text.contains(":")) {
            val c = text.substringAfter(":").trim()
            Store.resetDrama(c)
            return Reply("Concept save pannitten: $c")
        }
        val partNo = Regex("(?:part|பார்ட்)\\s*(\\d+)").find(t)?.groupValues?.get(1)?.toIntOrNull()
        if (has(t, video) && has(t, makeW)) {
            return Reply("Video file indha app-la illa. Script eduthu CapCut-la use pannunga. 'part 1 script eludhu' nu sollunga.")
        }
        if (has(t, drama) && has(t, partW)) {
            val inline = if (text.contains(":")) text.substringAfter(":").trim() else null
            return writePart(partNo, inline)
        }
        if (has(t, caption)) return Reply(Gemini.ask("Write 1 catchy Tanglish caption and 8 hashtags for: $text", remember = false))
        if (has(t, idea)) {
            return Reply(
                Gemini.ask(
                    "Topic: $text\nSuggest 3 short-video ideas (Instagram Reel / YouTube Short) with a hook line each. Tamil audience. Keep it brief.",
                    remember = false
                )
            )
        }

        // ---- maths & decisions ----
        Calc.answer(t)?.let { return Reply(it) }
        if (has(t, decide)) return Reply(Gemini.ask(text, system = Gemini.DECISION, remember = false))

        return Reply(Gemini.ask(text))
    }

    private fun batteryText(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val pct = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Battery $pct percent, " + if (charging) "charge aagudhu." else "charge aagala."
    }

    private fun parseTime(t: String): Pair<Int, Int>? {
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|மணி)?").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val mark = m.groupValues[3]
        if ((mark == "pm" || t.contains("மாலை") || t.contains("இரவு")) && h < 12) h += 12
        if ((mark == "am" || t.contains("காலை")) && h == 12) h = 0
        return if (h < 24 && min < 60) h to min else null
    }

    private fun writePart(requested: Int?, newConcept: String?): Reply {
        if (!newConcept.isNullOrBlank()) Store.resetDrama(newConcept)
        val concept = Store.concept
        if (concept.isBlank()) return Reply("Munnadi concept sollunga. Example: 'concept: college la oru ghost love story'.")
        val parts = Store.parts()
        val part = requested ?: (parts.length() + 1)
        val prev = parts.optJSONObject((part - 1).toString())
        val previous = if (prev != null) {
            val sc = prev.getJSONArray("scenes")
            "Previous part summary: " + (0 until sc.length()).joinToString(" | ") { sc.getJSONObject(it).optString("voice") }
        } else "This is the first part."
        val raw = Gemini.ask(
            "Write part $part of a Tamil micro drama (vertical video, 45-60 seconds).\nConcept: $concept\n$previous\n" +
                "Return ONLY JSON: {\"title\": str, \"scenes\": [{\"caption\": str (max 12 words, Tanglish), " +
                "\"voice\": str (dialogue/narration, Tanglish), \"visual\": str (shot description)}]} with 5-7 scenes. " +
                "End with a cliffhanger hook for the next part.",
            remember = false
        )
        val json = Regex("\\{[\\s\\S]*\\}").find(raw)?.value ?: return Reply(raw)
        return try {
            val obj = JSONObject(json)
            val arr = obj.getJSONArray("scenes")
            if (arr.length() == 0) return Reply("Script generate aagala. Marubadi try pannunga.")
            Store.savePart(part, obj)
            val scenes = (0 until arr.length()).map {
                val s = arr.getJSONObject(it)
                Scene(s.optString("caption"), s.optString("voice"), s.optString("visual"))
            }
            Reply("Part $part script ready, ${scenes.size} scenes.", script = Script(part, obj.optString("title"), scenes))
        } catch (e: Exception) {
            Reply("Script generate aagala. Marubadi try pannunga.")
        }
    }
}
